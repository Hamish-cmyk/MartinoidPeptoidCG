# -*- coding: utf-8 -*-
"""
Created on Thu Sep  7 10:40:29 2023

@author: rkb19187
"""


# import submodules
from Martinoid import _martinoid_data
from Martinoid.Martinoid2 import *



